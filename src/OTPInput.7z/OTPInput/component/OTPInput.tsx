/* eslint-disable prettier/prettier */
import React, { useRef, useState,useEffect } from 'react';
import { Pressable, StyleSheet, TextInput, View, Text, Linking } from 'react-native';

const OTPInput = ({ code, setCode, maximumLength, setIsPinReady }) => {
  const boxArray = new Array(maximumLength).fill(0);
  const inputRef = useRef<any>([]);
  const [state,setState] = useState()
  const ItemSperator = () => (<View style={{flex:1,backgroundColor:'yellow',paddingHorizontal:10}} />)

  const setInputCode = (text,index) => {
    setState(text)
    console.log("setInputCode index",index)
    console.log("setInputCode inputRef.current[index]",inputRef.current[index])
    inputRef.current[index+1].focus()

  }

  // eslint-disable-next-line react/no-unstable-nested-components
  const InputTextBox = (item: any,index: any,array) => {
    console.log("index",index,"item",item)
    // console.log('inputRef.current',inputRef.current)
    // style={{marginLeft:((array.lenght-1) === index || index ===0 ) ? 0 :20  }}
    return (
      // eslint-disable-next-line react-native/no-inline-styles
      <View key = {index} >

        <TextInput
        inputMode = {'numeric'}
        style={styles.textInputHidden}
        ref={(el)=>(inputRef.current[index] = el)}
        // value={code}
        onChangeText={(text)=>setInputCode(text,index)}
        maxLength={1}
        // onBlur={handleOnBlur}
        keyboardType="numeric"
        />
        </View>
    );
  };


  return (
    <View style={{}}>
      {/* <Pressable onPress={handleOnPress} style={styles.SplitOTPBoxesContainer}>
      </Pressable> */}
      <View style={styles.SplitOTPBoxesContainer}>
        {boxArray.map(InputTextBox)}
      </View>

      {/* <Pressable onPress={openMap}>
        <Text>Press Me to open map</Text>
      </Pressable> */}

    </View>
  );
};

export const styles = StyleSheet.create({
  otpInputContainer: {
    // justifyContent: 'center',
    // alignItems: 'center',
    // alignContent: 'center',
  },
  textInputHidden: {
    borderColor: '#e5e5e5',
    borderWidth: 1,
    borderRadius: 5,
    color:'red',
    width:50,
    height:50,
    justifyContent:'center',
    textAlign:'center'
  },
  SplitOTPBoxesContainer: {
    justifyContent: 'center',
    alignItems:'center',
    // marginVertical:10,
    flex:1,
    flexDirection: 'row',
    columnGap:15,

  },
  SplitBoxes: {
    borderColor: 'cyan',
    borderWidth: 2,
    borderRadius: 5,
    padding: 10,
    minWidth: 50,
    // marginHorizontal:15
  },
  SplitBoxText: {
    fontSize: 20,
    textAlign: 'center',
    color: '#e5e5e5',

  },
  SplitBoxShadowFoused: {
    borderColor: 'red',
    backgroundColor: 'grey',
    borderWidth: 2,
    borderRadius: 5,
    padding: 10,
    minWidth: 50,
  },


});

export default OTPInput;
