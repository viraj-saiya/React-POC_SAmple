/* eslint-disable prettier/prettier */
/* eslint-disable semi */


import { View, Text, StyleSheet, StatusBar } from 'react-native'
import React, { useState } from 'react'
import OTPInput from './component/OTPInput';

export default function OTPINPUT() {
  const [otpCode, setOTPCode] = useState("");
  const [isPinReady, setIsPinReady] = useState(false);
  const maximumCodeLength = 6;
  return (
    <View style={styles.container}>
      <OTPInput 
        code={otpCode}
        setCode={setOTPCode}
        maximumLength={maximumCodeLength}
        setIsPinReady={setIsPinReady}
      
      
      />
      <StatusBar style="auto" />
    </View>
  );
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#141414",
    alignItems: "center",
    justifyContent: "center",
  },
});
